# Detector de pantalla para Android

Esta app reconoce objetos de fotos y vídeos visibles en la pantalla del teléfono y dibuja recuadros con etiquetas en español sobre otras apps. Usa MediaProjection y una superposición no interactiva; puedes seguir tocando las aplicaciones que tienes debajo.

Este proyecto contiene el código fuente, el modelo de detección y Gradle Wrapper. **No contiene un APK compilado. No se ha compilado ni validado en un teléfono real en este entorno.** Necesitas una computadora para compilarlo antes de instalarlo.

## Compilar e instalar

1. Instala Android Studio con JDK 17 y Android SDK 35. La primera sincronización descarga Gradle y las dependencias y necesita internet.
2. Descomprime `detector-android.zip` y abre la carpeta `detector-android` en Android Studio. Si trabajas desde este repositorio, abre `android/`.
3. Deja que Android Studio sincronice el proyecto. Conecta tu teléfono Android 8 o posterior mediante USB, activa la depuración USB y selecciónalo como dispositivo.
4. Ejecuta la aplicación desde Android Studio. También puedes generar un APK de depuración con `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). El resultado estará en `app/build/outputs/apk/debug/app-debug.apk`.
5. Si instalas ese APK manualmente, Android solicita autorización para instalar desde la app con la que lo abres. El APK de depuración es para pruebas personales; una distribución pública requiere firma de publicación.

## Usar la detección

1. Abre **Detector de pantalla**.
2. Toca **Permitir marcas sobre otras apps** y concede el permiso para esta aplicación. Vuelve al detector.
3. Toca **Iniciar detección de pantalla**. Autoriza las notificaciones para tener disponible el botón **Detener** en la notificación.
4. Autoriza la captura de **toda la pantalla** en el diálogo de Android. Compartir una sola app puede desalinear las marcas al cambiar de ventana, por lo que la app solicita la pantalla completa.
5. Abre una foto o un vídeo en otra aplicación. Los objetos que el modelo reconoce con al menos un 50 % de confianza se marcan en español.
6. Detén la sesión desde la notificación o desde la aplicación. Android también puede finalizarla desde su indicador de captura. Al bloquear el teléfono se detiene automáticamente.

Cada nueva sesión solicita un permiso de captura nuevo. La captura no se inicia al encender el teléfono ni vuelve a activarse por sí sola si Android cierra el proceso. Si deniegas las notificaciones, Android permite la sesión, pero el botón de la notificación puede no aparecer: utiliza el indicador del sistema o vuelve a la app para detenerla.

## Qué reconoce y qué no

El modelo COCO SSD MobileNet v1 reconoce 80 categorías de objetos cotidianos. No es un asistente general para leer pantallas: no interpreta todos los textos, botones o iconos, no pulsa controles y no usa el servicio de accesibilidad. Las etiquetas no garantizan que el objeto esté presente; puede haber errores y objetos sin reconocer.

Las apps con contenido protegido pueden mostrar una captura vacía y algunas bloquean las superposiciones. Las marcas se refrescan como máximo dos veces por segundo para limitar el trabajo del dispositivo, por lo que pueden retrasarse ante movimientos rápidos. Algunos fabricantes restringen los servicios en segundo plano.

## Privacidad y permisos

Las imágenes se procesan en memoria en el teléfono, no se almacenan y no se envían a ningún servidor. El modelo está incluido. La app no solicita permiso de internet, cámara, micrófono, almacenamiento ni accesibilidad.

Solicita `SYSTEM_ALERT_WINDOW` para las marcas; `FOREGROUND_SERVICE` y `FOREGROUND_SERVICE_MEDIA_PROJECTION` para mantener la captura autorizada mientras usas otras apps; y `POST_NOTIFICATIONS` en Android 13 o posterior para sus controles. El aviso de captura del sistema permanece visible mientras está activa.

## Validación pendiente en Android

Antes de distribuir un APK, comprueba la compilación con Android Studio y las sesiones reales en Android 8, 12, 14 y 15 o posterior. Revisa conceder y denegar cada permiso, girar la pantalla, detener desde la app/notificación/sistema, bloquear el teléfono y revocar la superposición durante una sesión. Confirma que las marcas coinciden con objetos conocidos y que los toques pasan a la app que está debajo. Comprueba también un dispositivo con páginas de memoria de 16 KB si se va a distribuir para esos teléfonos.

La implementación reutiliza el mismo VirtualDisplay al girar el teléfono, como requiere Android 14 o posterior, libera los recursos al detenerse y no conserva los permisos de captura para sesiones futuras.

Los detalles y licencias del modelo, del runtime y de Gradle Wrapper están en `THIRD_PARTY_NOTICES.md`.
