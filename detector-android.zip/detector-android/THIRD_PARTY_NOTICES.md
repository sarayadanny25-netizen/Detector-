# Componentes de terceros

## Modelo COCO SSD MobileNet v1

Se incluyó `detect.tflite`, procedente del modelo cuantizado SSD MobileNet v1 publicado por TensorFlow el 29 de junio de 2018.

Fuente: https://storage.googleapis.com/download.tensorflow.org/models/tflite/coco_ssd_mobilenet_v1_1.0_quant_2018_06_29.zip

SHA-256 de `detect.tflite`: `e4b118e5e4531945de2e659742c7c590f7536f8d0ed26d135abcfe83b4779d13`

El mapa original de etiquetas se tradujo al español manteniendo los 91 índices, incluidos los índices reservados. Existen 80 categorías reconocibles.

El proyecto TensorFlow Models se distribuye bajo Apache License 2.0: https://github.com/tensorflow/models/blob/master/LICENSE

## LiteRT

La dependencia `com.google.ai.edge.litert:litert:1.4.0` se obtiene desde Google Maven durante la sincronización. Proporciona la API local `org.tensorflow.lite.Interpreter`.

Proyecto y licencia Apache 2.0: https://github.com/google-ai-edge/LiteRT

## Gradle Wrapper

Se incluyó el wrapper oficial de Gradle 8.9, sin modificaciones. La descarga de la distribución está fijada y protegida por SHA-256 en `gradle-wrapper.properties`.

Fuente: https://github.com/gradle/gradle/tree/v8.9.0/gradle/wrapper

Licencia Apache 2.0: https://github.com/gradle/gradle/blob/v8.9.0/LICENSE

Una copia de Apache License 2.0 se incluye en `licenses/Apache-2.0.txt`.
