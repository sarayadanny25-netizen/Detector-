package app.detector.pantalla;

import android.graphics.RectF;

final class Detection {
    final RectF bounds;
    final String label;
    final float score;

    Detection(RectF bounds, String label, float score) {
        this.bounds = new RectF(bounds);
        this.label = label;
        this.score = score;
    }
}
