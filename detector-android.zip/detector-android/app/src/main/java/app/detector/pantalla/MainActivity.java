package app.detector.pantalla;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 10, NOTIFICATION_REQUEST = 11;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView status;
    private Button permissions, start, stop;
    private boolean requestingCapture;
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateState();
            ui.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(16, 20, 24));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(32), dp(24), dp(32));
        scroll.addView(content);
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        addText(content, "ANDROID · DETECCIÓN EN PANTALLA", 12, 0xff2ecc71, false);
        addText(content, "Detector de objetos", 32, Color.WHITE, true);
        addText(content, "Reconoce objetos de fotos y vídeos que aparecen en otras apps y los marca sobre tu pantalla.", 18, 0xffc7d0d7, false);
        addText(content, "1. Permite mostrar las marcas sobre otras apps.\n\n2. Inicia la detección y autoriza compartir toda la pantalla.\n\n3. Abre la foto o el vídeo que quieres analizar.", 16, 0xffc7d0d7, false);
        permissions = button(content, "Permitir marcas sobre otras apps", false);
        permissions.setOnClickListener(view -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        start = button(content, "Iniciar detección de pantalla", true);
        start.setOnClickListener(view -> begin());
        stop = button(content, "Detener detección", false);
        stop.setOnClickListener(view -> {
            stopService(new Intent(this, ScreenDetectorService.class));
            updateState();
        });
        status = addText(content, "", 16, 0xff2ecc71, false);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        addText(content, "Tú controlas la captura", 20, Color.WHITE, true);
        addText(content, "Puedes seguir usando otras apps. Android mantiene un aviso de captura y puedes detenerla desde la notificación o desde aquí. Cada nueva sesión requiere tu autorización.", 15, 0xffc7d0d7, false);
        addText(content, "Las imágenes se procesan en este teléfono. No se guardan ni se envían. No se usa la cámara, el micrófono ni accesibilidad.", 15, 0xffc7d0d7, false);
        addText(content, "Reconoce 80 tipos de objetos cotidianos; no interpreta todos los textos, botones o iconos. Algunas apps protegidas bloquean la captura o las superposiciones. Al bloquear el teléfono, la detección se detiene.", 14, 0xff9aa8b3, false);
        setContentView(scroll);
    }

    private void begin() {
        if (ScreenDetectorService.isRunning || requestingCapture) return;
        if (!Settings.canDrawOverlays(this)) {
            status.setText("Primero permite mostrar marcas sobre otras apps.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        } else {
            requestCapture();
        }
    }

    private void requestCapture() {
        MediaProjectionManager manager = getSystemService(MediaProjectionManager.class);
        Intent consent = Build.VERSION.SDK_INT >= 34
                ? manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                : manager.createScreenCaptureIntent();
        requestingCapture = true;
        start.setEnabled(false);
        startActivityForResult(consent, CAPTURE_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        // Android permits foreground capture even when drawer notifications are denied.
        // Its system capture indicator and the in-app stop control remain available.
        if (code == NOTIFICATION_REQUEST) requestCapture();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CAPTURE_REQUEST) return;
        requestingCapture = false;
        if (result != RESULT_OK || data == null) {
            ScreenDetectorService.lastStatus = "Captura cancelada. Puedes iniciar otra sesión cuando quieras.";
            updateState();
            return;
        }
        Intent service = new Intent(this, ScreenDetectorService.class)
                .setAction(ScreenDetectorService.ACTION_START)
                .putExtra(ScreenDetectorService.EXTRA_RESULT_CODE, result)
                .putExtra(ScreenDetectorService.EXTRA_RESULT_DATA, data);
        try {
            startForegroundService(service);
            ScreenDetectorService.lastStatus = "Iniciando detección…";
        } catch (RuntimeException error) {
            ScreenDetectorService.lastStatus = "Android no permitió iniciar la captura. Vuelve a intentarlo con la app abierta.";
        }
        updateState();
    }

    private void updateState() {
        boolean allowed = Settings.canDrawOverlays(this);
        boolean running = ScreenDetectorService.isRunning;
        permissions.setText(allowed ? "Permiso de marcas concedido" : "Permitir marcas sobre otras apps");
        start.setEnabled(allowed && !running && !requestingCapture);
        start.setAlpha(start.isEnabled() ? 1f : 0.5f);
        stop.setEnabled(running);
        stop.setAlpha(running ? 1f : 0.5f);
        String next = ScreenDetectorService.lastStatus;
        if (!status.getText().toString().equals(next)) status.setText(next);
    }

    @Override protected void onResume() {
        super.onResume();
        ui.post(refresh);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(refresh);
        super.onPause();
    }

    private TextView addText(LinearLayout parent, String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setLineSpacing(dp(4), 1f);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(-1, -2);
        layout.bottomMargin = dp(22);
        parent.addView(text, layout);
        return text;
    }

    private Button button(LinearLayout parent, String value, boolean primary) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setTextColor(primary ? 0xff04210f : Color.WHITE);
        button.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable background = new GradientDrawable();
        background.setColor(primary ? 0xff2ecc71 : 0xff1b222a);
        background.setCornerRadius(dp(12));
        button.setBackground(background);
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(-1, -2);
        layout.bottomMargin = dp(14);
        parent.addView(button, layout);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
