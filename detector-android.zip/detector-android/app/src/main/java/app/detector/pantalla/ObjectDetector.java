package app.detector.pantalla;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.RectF;
import android.media.Image;

import org.tensorflow.lite.Interpreter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Offline COCO SSD MobileNet v1 detector; called only on the capture thread. */
final class ObjectDetector implements AutoCloseable {
    private static final int SIZE = 300;
    private final Interpreter interpreter;
    private final List<String> labels = new ArrayList<>();
    private final ByteBuffer input = ByteBuffer.allocateDirect(SIZE * SIZE * 3)
            .order(ByteOrder.nativeOrder());
    private final float[][][] boxes = new float[1][10][4];
    private final float[][] classes = new float[1][10];
    private final float[][] scores = new float[1][10];
    private final float[] count = new float[1];
    private final Map<Integer, Object> outputs = new HashMap<>();

    ObjectDetector(Context context) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                context.getAssets().open("labels_es.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) labels.add(line);
        }
        try (AssetFileDescriptor asset = context.getAssets().openFd("detect.tflite");
             FileInputStream stream = new FileInputStream(asset.getFileDescriptor())) {
            ByteBuffer model = stream.getChannel().map(FileChannel.MapMode.READ_ONLY,
                    asset.getStartOffset(), asset.getDeclaredLength());
            interpreter = new Interpreter(model, new Interpreter.Options().setNumThreads(2));
        }
        try {
            interpreter.allocateTensors();
            int[][] expected = {{1, 10, 4}, {1, 10}, {1, 10}, {1}};
            for (int i = 0; i < expected.length; i++) {
                if (!Arrays.equals(interpreter.getOutputTensor(i).shape(), expected[i])) {
                    throw new IllegalStateException("Incompatible detector output");
                }
            }
        } catch (RuntimeException error) {
            interpreter.close();
            throw error;
        }
        outputs.put(0, boxes);
        outputs.put(1, classes);
        outputs.put(2, scores);
        outputs.put(3, count);
    }

    List<Detection> detect(Image source) {
        Image.Plane plane = source.getPlanes()[0];
        ByteBuffer rgba = plane.getBuffer();
        int rowStride = plane.getRowStride(), pixelStride = plane.getPixelStride();
        int offset = rgba.position();
        input.rewind();
        // Sample directly from the RGBA plane, including devices with row padding.
        // Only the 300x300 RGB input is allocated; no screenshot bitmap is retained.
        for (int y = 0; y < SIZE; y++) {
            int row = offset + (y * source.getHeight() / SIZE) * rowStride;
            for (int x = 0; x < SIZE; x++) {
                int pixel = row + (x * source.getWidth() / SIZE) * pixelStride;
                input.put(rgba.get(pixel));
                input.put(rgba.get(pixel + 1));
                input.put(rgba.get(pixel + 2));
            }
        }
        input.rewind();
        interpreter.runForMultipleInputsOutputs(new Object[]{input}, outputs);
        List<Detection> detections = new ArrayList<>();
        int total = Math.min(10, Math.max(0, (int) count[0]));
        for (int i = 0; i < total; i++) {
            if (!Float.isFinite(scores[0][i]) || scores[0][i] < 0.5f) continue;
            // The model returns zero-based COCO indices; label zero is reserved.
            int labelIndex = (int) classes[0][i] + 1;
            if (labelIndex < 1 || labelIndex >= labels.size()) continue;
            String label = labels.get(labelIndex);
            if ("???".equals(label)) continue;
            float[] box = boxes[0][i];
            RectF rect = new RectF(clamp(box[1]), clamp(box[0]), clamp(box[3]), clamp(box[2]));
            if (rect.width() <= 0 || rect.height() <= 0) continue;
            detections.add(new Detection(rect, label, scores[0][i]));
        }
        return detections;
    }

    private static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }

    @Override public void close() {
        interpreter.close();
    }
}
