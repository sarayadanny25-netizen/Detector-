package app.detector.pantalla;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.Collections;
import java.util.List;

/** A non-interactive overlay; coordinates include the captured system bars. */
final class OverlayView extends View {
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] origin = new int[2];
    private List<Detection> detections = Collections.emptyList();
    private int captureWidth = 1, captureHeight = 1;

    OverlayView(Context context) {
        super(context);
        float density = getResources().getDisplayMetrics().density;
        border.setColor(Color.rgb(46, 204, 113));
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(2 * density);
        fill.setColor(Color.rgb(46, 204, 113));
        text.setColor(Color.rgb(4, 33, 15));
        text.setTextSize(14 * getResources().getDisplayMetrics().scaledDensity);
        text.setFakeBoldText(true);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    void showDetections(List<Detection> next, int width, int height) {
        detections = next;
        captureWidth = width;
        captureHeight = height;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        getLocationOnScreen(origin);
        float pad = 5 * getResources().getDisplayMetrics().density;
        for (Detection detection : detections) {
            RectF b = detection.bounds;
            RectF rect = new RectF(b.left * captureWidth - origin[0],
                    b.top * captureHeight - origin[1],
                    b.right * captureWidth - origin[0], b.bottom * captureHeight - origin[1]);
            canvas.drawRect(rect, border);
            String label = detection.label + " " + Math.round(detection.score * 100) + "%";
            float width = Math.min(getWidth(), text.measureText(label) + 2 * pad);
            float height = text.getFontSpacing() + 2 * pad;
            float x = Math.max(0, Math.min(rect.left, getWidth() - width));
            float y = Math.max(0, Math.min(rect.top - height, getHeight() - height));
            canvas.drawRect(x, y, x + width, y + height, fill);
            canvas.drawText(label, x + pad, y + pad - text.ascent(), text);
        }
    }
}
