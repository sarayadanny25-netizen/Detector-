package app.detector.pantalla;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;

public final class ScreenDetectorService extends Service {
    static final String ACTION_START = "app.detector.pantalla.START";
    static final String ACTION_STOP = "app.detector.pantalla.STOP";
    static final String EXTRA_RESULT_CODE = "resultCode", EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "screen_detection";
    private static final int NOTIFICATION_ID = 100;
    public static volatile boolean isRunning;
    public static volatile String lastStatus = "Listo para iniciar. La captura solo comienza cuando tú la autorizas.";
    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread thread;
    private Handler worker;
    private Context overlayContext;
    private WindowManager windows;
    private DisplayManager displays;
    private OverlayView overlay;
    private ObjectDetector detector;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private volatile boolean stopping;
    private boolean screenReceiverRegistered, displayListenerRegistered;
    private volatile boolean capturedContentVisible = true;
    private volatile int geometryVersion;
    private int sourceWidth, sourceHeight, captureWidth, captureHeight;
    private long lastFrame;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            finishCapture("Detección detenida al bloquear la pantalla.");
        }
    };
    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() {
            finishCapture("Captura finalizada. Inicia otra sesión para volver a detectar.");
        }
        @Override public void onCapturedContentResize(int width, int height) {
            if (stopping || projection == null) return;
            try {
                resizeCapture(width, height);
            } catch (RuntimeException error) {
                finishCapture("No se pudo ajustar la captura. Inicia otra sesión.");
            }
        }
        @Override public void onCapturedContentVisibilityChanged(boolean visible) {
            capturedContentVisible = visible;
            if (!visible) clearOverlay();
        }
    };
    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int id) { }
        @Override public void onDisplayRemoved(int id) {
            if (id == Display.DEFAULT_DISPLAY) finishCapture("La pantalla ya no está disponible.");
        }
        @Override public void onDisplayChanged(int id) {
            // Newer releases report captured dimensions directly in projectionCallback.
            if (id != Display.DEFAULT_DISPLAY || Build.VERSION.SDK_INT >= 34 || stopping) return;
            try {
                int[] size = screenSize();
                resizeCapture(size[0], size[1]);
            } catch (RuntimeException error) {
                finishCapture("No se pudo ajustar la captura al girar el teléfono.");
            }
        }
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            finishCapture("Detección detenida.");
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || isRunning) return START_NOT_STICKY;
        Intent consent = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class)
                : intent.getParcelableExtra(EXTRA_RESULT_DATA);
        int result = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        if (consent == null || result != Activity.RESULT_OK || !Settings.canDrawOverlays(this)) {
            finishCapture("Concede los permisos de pantalla y superposición para iniciar.");
            return START_NOT_STICKY;
        }
        try {
            Notification notification = notification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            isRunning = true;
            stopping = false;
            lastStatus = "Cargando detector en el teléfono…";
            overlayContext = Build.VERSION.SDK_INT >= 30
                    ? createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, null)
                    : this;
            windows = overlayContext.getSystemService(WindowManager.class);
            displays = getSystemService(DisplayManager.class);
            addOverlay();
            IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, filter, RECEIVER_NOT_EXPORTED);
            else registerReceiver(screenOff, filter);
            screenReceiverRegistered = true;
            thread = new HandlerThread("object-detector");
            thread.start();
            worker = new Handler(thread.getLooper());
            worker.post(() -> initialize(result, consent));
        } catch (RuntimeException error) {
            finishCapture("No se pudo iniciar. Revisa los permisos y vuelve a intentarlo con la app abierta.");
        }
        return START_NOT_STICKY;
    }

    private void initialize(int result, Intent consent) {
        if (stopping) return;
        try {
            detector = new ObjectDetector(this);
            if (stopping) return;
            MediaProjectionManager manager = getSystemService(MediaProjectionManager.class);
            projection = manager.getMediaProjection(result, consent);
            if (projection == null) throw new IllegalStateException("No projection");
            projection.registerCallback(projectionCallback, worker);
            int[] size = screenSize();
            resizeCapture(size[0], size[1]);
            displays.registerDisplayListener(displayListener, worker);
            displayListenerRegistered = true;
            lastStatus = "Detectando. Abre una foto o un vídeo en otra app para ver las marcas.";
        } catch (Exception error) {
            finishCapture("No se pudo cargar el detector o iniciar la captura. Inicia una nueva sesión.");
        }
    }

    private int[] screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect bounds = windows.getMaximumWindowMetrics().getBounds();
            return new int[]{bounds.width(), bounds.height()};
        }
        DisplayMetrics metrics = new DisplayMetrics();
        windows.getDefaultDisplay().getRealMetrics(metrics);
        return new int[]{metrics.widthPixels, metrics.heightPixels};
    }

    private void resizeCapture(int width, int height) {
        if (width <= 0 || height <= 0 || stopping) return;
        if (reader != null && width == sourceWidth && height == sourceHeight) return;
        sourceWidth = width;
        sourceHeight = height;
        geometryVersion++;
        float ratio = Math.min(1f, 960f / Math.max(width, height));
        captureWidth = Math.max(1, Math.round(width * ratio));
        captureHeight = Math.max(1, Math.round(height * ratio));
        int density = getResources().getDisplayMetrics().densityDpi;
        ImageReader previous = reader;
        ImageReader next = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2);
        next.setOnImageAvailableListener(this::processFrame, worker);
        try {
            if (display == null) {
                display = projection.createVirtualDisplay("Detector de pantalla", captureWidth,
                        captureHeight, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        next.getSurface(), null, worker);
                if (display == null) throw new IllegalStateException("No virtual display");
            } else {
                // Reuse the existing display: Android 14+ forbids a second one per consent.
                display.setSurface(null);
                display.resize(captureWidth, captureHeight, density);
                display.setSurface(next.getSurface());
            }
            reader = next;
        } catch (RuntimeException error) {
            next.close();
            throw error;
        }
        if (previous != null) previous.close();
        clearOverlay();
    }

    private void processFrame(ImageReader source) {
        if (stopping || source != reader) return;
        try (Image image = source.acquireLatestImage()) {
            if (image == null || detector == null || !capturedContentVisible) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastFrame < 500) return;
            lastFrame = now;
            if (!Settings.canDrawOverlays(this)) {
                finishCapture("Se retiró el permiso para mostrar marcas sobre otras apps.");
                return;
            }
            List<Detection> detections = detector.detect(image);
            int width = sourceWidth, height = sourceHeight, version = geometryVersion;
            main.post(() -> {
                if (!stopping && capturedContentVisible && overlay != null && version == geometryVersion) {
                    overlay.showDetections(detections, width, height);
                }
            });
        } catch (Exception error) {
            if (!stopping) finishCapture("La detección se interrumpió. Inicia una nueva sesión.");
        }
    }

    private void addOverlay() {
        overlay = new OverlayView(overlayContext);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        // Below Android 12's maximum obscuring opacity so touches pass to other apps.
        params.alpha = 0.7f;
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        windows.addView(overlay, params);
    }

    private void clearOverlay() {
        main.post(() -> {
            if (overlay != null) overlay.showDetections(Collections.emptyList(), 1, 1);
        });
    }

    private Notification notification() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                "Detección de pantalla", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ScreenDetectorService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_detector)
                .setContentTitle("Detector de pantalla activo")
                .setContentText("Analizando objetos en este teléfono. Toca Detener para finalizar.")
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(null, "Detener", stop).build())
                .build();
    }

    private void finishCapture(String message) {
        if (stopping) return;
        stopping = true;
        lastStatus = message;
        main.post(() -> {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            stopSelf();
        });
    }

    @Override public void onDestroy() {
        stopping = true;
        isRunning = false;
        if (lastStatus.startsWith("Detectando") || lastStatus.startsWith("Cargando")) {
            lastStatus = "Detección detenida.";
        }
        if (screenReceiverRegistered) unregisterReceiver(screenOff);
        if (overlay != null) {
            if (overlay.isAttachedToWindow()) windows.removeView(overlay);
            overlay = null;
        }
        if (worker != null) {
            worker.post(() -> {
                if (displayListenerRegistered) displays.unregisterDisplayListener(displayListener);
                if (display != null) display.release();
                if (reader != null) reader.close();
                if (projection != null) {
                    projection.unregisterCallback(projectionCallback);
                    projection.stop();
                }
                if (detector != null) detector.close();
                thread.quitSafely();
            });
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
