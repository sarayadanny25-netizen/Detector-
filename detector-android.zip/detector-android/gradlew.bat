@echo off
setlocal
set "APP_DIR=%~dp0"
if defined JAVA_HOME (
  set "GRADLE_JAVA=%JAVA_HOME%\bin\java.exe"
) else (
  set "GRADLE_JAVA=java.exe"
)
"%GRADLE_JAVA%" -classpath "%APP_DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
